// --- Kustomak OS Data Manager - manager.js ---

document.addEventListener('DOMContentLoaded', () => {
    // Make a deep copy of the schedule data to avoid modifying the original object loaded from the script.
    // This allows for a "reset" functionality if needed.
    let editableSchedule = JSON.parse(JSON.stringify(scheduleData));
    const managerContainer = document.getElementById('manager-container');

    /**
     * Renders the entire schedule into editable components.
     */
    function render() {
        managerContainer.innerHTML = '';
        Object.keys(editableSchedule).forEach(day => {
            const dayColumn = document.createElement('div');
            dayColumn.className = 'day-column';
            dayColumn.innerHTML = `<h2>${day.charAt(0).toUpperCase() + day.slice(1)}</h2>`;

            editableSchedule[day].forEach((block, blockIndex) => {
                const timeBlock = document.createElement('div');
                timeBlock.className = 'time-block';
                timeBlock.innerHTML = `<div class="time-block-header">${block.timeRange}</div>`;

                const taskList = document.createElement('ul');
                taskList.className = 'task-list';
                taskList.dataset.day = day;
                taskList.dataset.blockIndex = blockIndex;
                
                block.tasks.forEach((task, taskIndex) => {
                    taskList.appendChild(createTaskItem(task, taskIndex));
                });

                timeBlock.appendChild(taskList);
                timeBlock.appendChild(createAddTaskButton(day, blockIndex));
                dayColumn.appendChild(timeBlock);
            });
            managerContainer.appendChild(dayColumn);
        });
    }

    /**
     * Creates a single editable task item element.
     */
    function createTaskItem(taskText, taskIndex) {
        const item = document.createElement('li');
        item.className = 'task-item';
        item.draggable = true;
        item.dataset.taskIndex = taskIndex;
        item.innerHTML = `
            <span class="drag-handle" title="Drag to reorder">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 3L6 13M10 3L10 13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
            </span>
            <input type="text" class="task-input" value="${escapeHTML(taskText)}">
            <button class="delete-btn" title="Delete Task">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2 5H14M4 5L4.89 13.61C4.93 14.16 5.39 14.6 5.94 14.6H10.06C10.61 14.6 11.07 14.16 11.11 13.61L12 5M6.5 5V2.5C6.5 2.22 6.72 2 7 2H9C9.28 2 9.5 2.22 9.5 2.5V5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </button>
        `;
        return item;
    }

    /**
     * Creates an "Add Task" button for a time block.
     */
    function createAddTaskButton(day, blockIndex) {
        const button = document.createElement('button');
        button.className = 'add-task-btn';
        button.textContent = '+ Add Task';
        button.dataset.day = day;
        button.dataset.blockIndex = blockIndex;
        return button;
    }

    /**
     * Handles all click events within the manager container.
     */
    function handleClick(e) {
        const target = e.target;
        if (target.matches('.add-task-btn')) {
            const { day, blockIndex } = target.dataset;
            editableSchedule[day][blockIndex].tasks.push("New Task - Edit Me");
            render(); // Re-render to show the new task
        }
        if (target.closest('.delete-btn')) {
            const item = target.closest('.task-item');
            const list = item.parentElement;
            const { day, blockIndex } = list.dataset;
            const taskIndex = parseInt(item.dataset.taskIndex, 10);
            editableSchedule[day][blockIndex].tasks.splice(taskIndex, 1);
            render(); // Re-render to reflect deletion
        }
    }

    /**
     * Handles updates when the user types in an input field.
     */
    function handleInput(e) {
        const target = e.target;
        if (target.matches('.task-input')) {
            const item = target.closest('.task-item');
            const list = item.parentElement;
            const { day, blockIndex } = list.dataset;
            const taskIndex = parseInt(item.dataset.taskIndex, 10);
            editableSchedule[day][blockIndex].tasks[taskIndex] = target.value;
        }
    }

    /**
     * Handles drag and drop for reordering tasks.
     */
    let draggedItem = null;
    function handleDragAndDrop(e) {
        const target = e.target;
        if (target.matches('.task-item')) {
            if (e.type === 'dragstart') {
                draggedItem = target;
                setTimeout(() => target.classList.add('is-dragging'), 0);
            }
            if (e.type === 'dragend') {
                draggedItem.classList.remove('is-dragging');
                draggedItem = null;
            }
        }
        if (target.closest('.task-list')) {
            if (e.type === 'dragover') {
                e.preventDefault();
                const list = target.closest('.task-list');
                const afterElement = getDragAfterElement(list, e.clientY);
                if (afterElement == null) {
                    list.appendChild(draggedItem);
                } else {
                    list.insertBefore(draggedItem, afterElement);
                }
            }
            if (e.type === 'drop') {
                updateDataOrder(target.closest('.task-list'));
            }
        }
    }

    function getDragAfterElement(container, y) {
        const draggableElements = [...container.querySelectorAll('.task-item:not(.is-dragging)')];
        return draggableElements.reduce((closest, child) => {
            const box = child.getBoundingClientRect();
            const offset = y - box.top - box.height / 2;
            if (offset < 0 && offset > closest.offset) {
                return { offset: offset, element: child };
            } else {
                return closest;
            }
        }, { offset: Number.NEGATIVE_INFINITY }).element;
    }
    
    function updateDataOrder(list) {
        const { day, blockIndex } = list.dataset;
        const newOrderedTasks = [];
        list.querySelectorAll('.task-item .task-input').forEach(input => {
            newOrderedTasks.push(input.value);
        });
        editableSchedule[day][blockIndex].tasks = newOrderedTasks;
        render(); // Re-render to fix indices and confirm order
    }

    /**
     * Generates the final output code.
     */
    function generateOutput() {
        const outputString = `const scheduleData = ${JSON.stringify(editableSchedule, null, 4)};`;
        const exportTextarea = document.getElementById('export-textarea');
        exportTextarea.value = outputString;
        document.getElementById('export-modal').classList.remove('hidden');
    }
    
    // --- Utility Functions ---
    function escapeHTML(str) {
        const p = document.createElement("p");
        p.appendChild(document.createTextNode(str));
        return p.innerHTML;
    }

    // --- Initial Render & Event Listeners ---
    render();
    managerContainer.addEventListener('click', handleClick);
    managerContainer.addEventListener('input', handleInput);
    managerContainer.addEventListener('dragstart', handleDragAndDrop);
    managerContainer.addEventListener('dragover', handleDragAndDrop);
    managerContainer.addEventListener('dragend', handleDragAndDrop);
    managerContainer.addEventListener('drop', handleDragAndDrop);
    
    document.getElementById('generate-btn').addEventListener('click', generateOutput);
    document.getElementById('close-modal-btn').addEventListener('click', () => {
        document.getElementById('export-modal').classList.add('hidden');
    });
    document.getElementById('copy-btn').addEventListener('click', () => {
        const textarea = document.getElementById('export-textarea');
        textarea.select();
        document.execCommand('copy');
        const copyBtn = document.getElementById('copy-btn');
        copyBtn.textContent = 'Copied!';
        setTimeout(() => { copyBtn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" width="20"><path d="M7 3.5A1.5 1.5 0 0 1 8.5 2h3.879a1.5 1.5 0 0 1 1.06.44l3.122 3.12A1.5 1.5 0 0 1 17 6.622V16.5a1.5 1.5 0 0 1-1.5 1.5h-8A1.5 1.5 0 0 1 6 16.5v-3a.75.75 0 0 1 1.5 0v3h8V7.122l-2.622-2.622H8.5A.5.5 0 0 0 8 5v.75a.75.75 0 0 1-1.5 0V5a1.5 1.5 0 0 1 .5-1.224V3.5Z" /><path d="M4.125 3.5a.75.75 0 0 0-1.5 0v12A2.25 2.25 0 0 0 4.875 18h8.25a.75.75 0 0 0 0-1.5h-8.25A.75.75 0 0 1 4.125 16V3.5Z" /></svg> Copy to Clipboard`; }, 2000);
    });
});
