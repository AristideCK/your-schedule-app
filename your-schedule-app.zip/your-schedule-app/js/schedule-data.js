// This file acts as a local database.
// It creates a single global variable, `scheduleData`,
// that contains the entire weekly schedule.

const scheduleData = {
  "monday": [
    {
      "timeRange": "10:00 AM - 1:30 PM", "pomodoros": 7, "focus": "Q1 Client E-commerce",
      "tasks": [
        "Facebook (Ecommerce): Review analytics & plan week's posts.", "Facebook (Ecommerce): Draft & get approval for today's primary post.", "Instagram (Ecommerce): Review analytics & plan week's content.", "Instagram (Ecommerce): Draft & get approval for today's primary post.", "Tiktok (Ecommerce): Research trending sounds/formats.", "Twitter (Ecommerce): Schedule 3-5 relevant tweets for the day.", "Account Calendar (Ecommerce): Update calendar with all planned posts."
      ]
    },
    {
      "timeRange": "2:45 PM - 5:00 PM", "pomodoros": 4, "focus": "Q1 Client Community Management",
      "tasks": [
        "Facebook (Comm. Mgt): Respond to comments & messages.", "Facebook (Comm. Mgt): Post one engaging question/poll.", "Instagram (Comm. Mgt): Respond to comments & DMs.", "Whatsapp (Comm. Mgt): Clear all unread messages."
      ]
    },
    {
      "timeRange": "11:00 PM - 3:00 AM", "pomodoros": 8, "focus": "Q2 Deep Work & Business Building",
      "tasks": [
        "Building Your Business Website: Work on primary development task.", "Building Your Business Website: Continue development task.", "Building Your Business Website: Debug or refine a feature.", "Client Workflow: Review previous week's projects for friction points.", "Client Workflow: Draft one process improvement.", "Facebook (Graphic Design): Curate and schedule one portfolio post.", "Instagram (Graphic Design): Curate and schedule one portfolio post.", "Twitter (Graphic Design): Engage with 5-10 other designers/potential clients."
      ]
    }
  ],
  "tuesday": [
    {
      "timeRange": "10:00 AM - 1:30 PM", "pomodoros": 7, "focus": "Q1 Client E-commerce",
      "tasks": [
        "Facebook (Ecommerce): Execute today's campaign/post.", "Facebook (Ecommerce): Engage with comments on live posts.", "Instagram (Ecommerce): Execute today's Story/Reel/Post.", "Instagram (Ecommerce): Engage with comments on live posts.", "Tiktok (Ecommerce): Film/edit one video.", "Tiktok (Ecommerce): Write caption and post video.", "Video Editing App (Capcut) (Ec...): Create one video asset for later use."
      ]
    },
    {
      "timeRange": "2:45 PM - 5:00 PM", "pomodoros": 4, "focus": "Q1 Client Community Management",
      "tasks": [
        "Community Hub: Check main feed and respond to 5+ posts.", "Community Hub: Welcome new members.", "Whatsapp (Graphic Design): Clear all unread client messages.", "Tiktok (Community Manager): Post one community-related video/update."
      ]
    },
    {
      "timeRange": "11:00 PM - 3:00 AM", "pomodoros": 8, "focus": "Q2 Deep Work & Business Building",
      "tasks": [
        "Building Your Business Website: Continue development task.", "Building Your Business Website: Work on site copy/SEO.", "Video Editing (Graphic Design): Work on a portfolio video piece.", "Video Editing (Graphic Design): Continue editing.", "Instagram (Graphic Design): Engage with comments and other accounts.", "Twitter (Graphic Design): Schedule 3-5 relevant tweets for the day.", "Facebook (Graphic Design): Engage with comments and relevant groups.", "Client Workflow: Implement the process improvement drafted yesterday."
      ]
    }
  ],
  "wednesday": [
    {
        "timeRange": "10:00 AM - 1:30 PM", "pomodoros": 7, "focus": "Q1 Client E-commerce",
        "tasks": [
            "Facebook (Ecommerce): Execute today's campaign/post.", "Instagram (Ecommerce): Execute today's Story/Reel/Post.", "Tiktok (Ecommerce): Engage with comments & other videos.", "Twitter (Ecommerce): Live tweet/engage during peak hours.", "Account Calendar (Ecommerce): Plan content for the next 2-3 days.", "Video Editing App (Capcut) (Ec...): Create one video asset for later use.", "Facebook (Ecommerce): A/B test one ad or post headline."
        ]
    },
    {
        "timeRange": "2:45 PM - 5:00 PM", "pomodoros": 4, "focus": "Q1 Client Community Management",
        "tasks": [
            "Facebook (Comm. Mgt): Respond to all comments & messages.", "Instagram (Comm. Mgt): Post one engaging Story/Reel.", "Community Hub: Host a small, time-boxed engagement event (e.g., \"Ask me anything for 30 mins\").", "Whatsapp (Comm. Mgt): Send out a broadcast/update if needed."
        ]
    },
    {
        "timeRange": "11:00 PM - 3:00 AM", "pomodoros": 8, "focus": "Q2 Deep Work & Business Building",
        "tasks": [
            "Building Your Business Website: Finalize weekly development task.", "Building Your Business Website: Test feature on mobile/desktop.", "Tiktok (Graphic Design): Work on a portfolio video piece.", "Tiktok (Graphic Design): Continue editing.", "Instagram (Graphic Design): Create a high-effort portfolio piece (e.g., carousel).", "Instagram (Graphic Design): Write compelling copy for the post.", "Twitter (Graphic Design): Draft a short thread showcasing your expertise.", "Account Calendar (Ecommerce): Research holidays/events for next month's content."
        ]
    }
  ],
  "thursday": [
    {
        "timeRange": "10:00 AM - 1:30 PM", "pomodoros": 7, "focus": "Q1 Client E-commerce",
        "tasks": [
            "Facebook (Ecommerce): Check ad performance; adjust bids if necessary.", "Facebook (Ecommerce): Respond to all comments and messages.", "Instagram (Ecommerce): Check Story/Reel performance.", "Instagram (Ecommerce): Respond to all comments and DMs.", "Tiktok (Ecommerce): Analyze video performance; plan next video.", "Twitter (Ecommerce): Monitor trending topics; engage in relevant conversations.", "Facebook (Ecommerce): Test different ad copy variations."
        ]
    },
    {
        "timeRange": "2:45 PM - 5:00 PM", "pomodoros": 4, "focus": "Q1 Client Community Management",
        "tasks": [
            "Community Hub: Moderate discussions, remove spam.", "Community Hub: Highlight a top contributor.", "Whatsapp (Comm. Mgt): Respond to all direct messages.", "Instagram (Comm. Mgt): Run a Q&A session in Stories."
        ]
    },
    {
        "timeRange": "11:00 PM - 3:00 AM", "pomodoros": 8, "focus": "Q2 Deep Work & Business Building",
        "tasks": [
            "Building Your Business Website: Review site analytics; identify areas for improvement.", "Building Your Business Website: Implement one design change.", "Video Editing (Graphic Design): Export finished video.", "Video Editing (Graphic Design): Write descriptions and tags.", "Tiktok (Graphic Design): Upload video and promote on other channels.", "Instagram (Graphic Design): Engage with comments and other accounts.", "Twitter (Graphic Design): Schedule 3-5 relevant tweets for the day.", "Client Workflow: Document a successful project for future reference."
        ]
    }
  ],
  "friday": [
    {
        "timeRange": "10:00 AM - 1:30 PM", "pomodoros": 7, "focus": "Q1 Client E-commerce",
        "tasks": [
            "Facebook (Ecommerce): Execute today's campaign/post.", "Facebook (Ecommerce): Monitor ad spend and ROI.", "Instagram (Ecommerce): Execute today's Story/Reel/Post.", "Instagram (Ecommerce): Run a contest or giveaway.", "Tiktok (Ecommerce): Respond to comments and DMs.", "Twitter (Ecommerce): Participate in a relevant Twitter chat.", "[Client Outreach/Sales]: Follow up with warm leads."
        ]
    },
    {
        "timeRange": "2:45 PM - 5:00 PM", "pomodoros": 4, "focus": "Q1 Client Communication & Admin",
        "tasks": [
            "Whatsapp (Graphic Design): Respond to all client messages.", "[Client Outreach/Sales]: Send out 3-5 personalized pitch emails.", "[Client Outreach/Sales]: Prepare invoices.", "[Client Outreach/Sales]: Send out invoices and payment reminders."
        ]
    },
    {
        "timeRange": "11:00 PM - 3:00 AM", "pomodoros": 8, "focus": "Q2 Deep Work & Business Building",
        "tasks": [
            "Building Your Business Website: Research a new feature to add.", "Building Your Business Website: Plan the implementation of that feature.", "Facebook (Graphic Design): Seek feedback on a portfolio piece in a group.", "Facebook (Graphic Design): Engage with comments and relevant groups.", "Instagram (Graphic Design): Research new trends in your design niche.", "Instagram (Graphic Design): Plan a series of posts around a theme.", "Twitter (Graphic Design): Share a valuable resource for other designers.", "Client Workflow: Update your pricing sheet."
        ]
    }
  ],
  "saturday": [
    {
        "timeRange": "10:00 AM - 1:30 PM", "pomodoros": 7, "focus": "Q1 Weekly Wrap-up & Performance Review",
        "tasks": [
            "Facebook (Ecommerce): Analyze the week's post performance and compile key metrics.", "Instagram (Ecommerce): Analyze the week's post performance and compile key metrics.", "Tiktok (Ecommerce): Final check on comments and engagement for the week.", "Twitter (Ecommerce): Schedule light, engaging posts for the rest of the weekend.", "Video Editing App (Capcut) (Ec...): Organize files and templates from the week's work.", "[Client Outreach/Sales]: Review lead pipeline and update your CRM/notes.", "Account Calendar (Ecommerce): Draft a brief performance summary email for clients."
        ]
    },
    {
        "timeRange": "2:45 PM - 5:00 PM", "pomodoros": 4, "focus": "Q1 Final Client Comms & Engagement",
        "tasks": [
            "Community Hub: Post a \"Happy Weekend\" message and engage with replies.", "Facebook (Comm. Mgt): Final check and response to any urgent messages.", "Instagram (Comm. Mgt): Final check on DMs and comments.", "Whatsapp (Graphic Design): Send a brief \"end of week\" status update to active clients."
        ]
    },
    {
        "timeRange": "11:00 PM - 3:00 AM", "pomodoros": 8, "focus": "Q2 Major Deep Work Session",
        "tasks": [
            "Building Your Business Website: Make a major push on a single feature or page.", "Building Your Business Website: Continue the major push.", "Building Your Business Website: Continue the major push.", "Building Your Business Website: Test and document the work done tonight.", "Facebook (Graphic Design): Work on a complex portfolio piece.", "Instagram (Graphic Design): Finalize and schedule all portfolio posts for the coming week.", "Twitter (Graphic Design): Write and schedule a valuable thread for Monday.", "Client Workflow: Update your own master project tracker."
        ]
    }
  ],
  "sunday": [
    {
        "timeRange": "10:00 AM - 1:30 PM", "pomodoros": 7, "focus": "Q2 Personal & Business Weekly Review",
        "tasks": [
            "Personal Review: Go through your Trello \"Done Today/This Week\" list. Acknowledge accomplishments.", "Financial Review: Check payments received and invoices outstanding.", "Client Performance Review: Look at the client summaries you drafted. What worked? What didn't?", "Facebook (Ecommerce): Final check on weekend ad performance.", "Instagram (Ecommerce): Final check on weekend engagement.", "Tiktok (Ecommerce): Brainstorm 5 ideas for next week's videos.", "Video Editing App (Capcut) (Ec...): Create one template for a recurring video format."
        ]
    },
    {
        "timeRange": "2:45 PM - 5:00 PM", "pomodoros": 4, "focus": "Q2 Light Engagement & Reset",
        "tasks": [
            "Community Hub: Lightly engage with any weekend discussions.", "Whatsapp (Comm. Mgt): Check for any urgent community messages.", "Tiktok (Community Manager): Brainstorm ideas for next week.", "Inbox Zero: Clear out your email inbox to prepare for Monday."
        ]
    },
    {
        "timeRange": "11:00 PM - 3:00 AM", "pomodoros": 8, "focus": "Q2 Planning for the Week Ahead",
        "tasks": [
            "Trello Prep: Move all cards from \"Done Today\" to a \"Done This Week\" archive list.", "Goal Setting: Define your Top 3 priorities for the upcoming week.", "Task Breakdown: Go to your Project Backlog in Trello. Create the small, actionable task cards for the week ahead.", "Task Breakdown: Continue creating task cards.", "Account Calendar (Ecommerce): Populate the content calendar with all the tasks you just created.", "Client Workflow: Create Trello checklists for any new or complex projects starting next week.", "Scheduling: Roughly map out your most important tasks for Mon/Tues/Wed.", "Final Review: Look at your board. It should now be perfectly clean and prepped for you to execute."
        ]
    }
  ]
};
