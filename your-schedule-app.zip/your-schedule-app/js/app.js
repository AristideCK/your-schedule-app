// --- Kustomak Pomodoro System - app.js (v3.0 - Final Interactive) ---

document.addEventListener('DOMContentLoaded', () => {

    // --- Global State & DOM Elements ---
    const scheduleContainer = document.getElementById('schedule-container');
    const navLinks = document.querySelectorAll('.nav-day-link');
    const currentTimeEl = document.getElementById('current-time');

    let timerState = {
        intervalId: null,
        isRunning: false,
        activeCardId: null,
    };

    // --- Main Initialization ---
    function init() {
        if (typeof scheduleData === 'undefined') {
            scheduleContainer.innerHTML = `<p class="error-message">FATAL ERROR: schedule-data.js not found.</p>`;
            return;
        }
        
        const scheduleWithEdits = applyTextEdits(scheduleData);
        renderAllDays(scheduleWithEdits);
        setupEventListeners();
        
        const todayName = new Date().toLocaleString('en-US', { weekday: 'long' }).toLowerCase();
        const initialDay = window.location.hash.replace('#', '') || todayName;
        const validDays = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
        
        switchDay(validDays.includes(initialDay) ? initialDay : todayName);
        loadState();
        
        updateTimeAndHighlight();
        setInterval(updateTimeAndHighlight, 15000); // Update every 15 seconds for accuracy
    }

    // --- Data Handling ---
    function applyTextEdits(originalData) {
        const edits = JSON.parse(localStorage.getItem('kustomakScheduleEdits')) || {};
        const dataWithEdits = JSON.parse(JSON.stringify(originalData));
        for (const day in dataWithEdits) {
            dataWithEdits[day].forEach(block => {
                block.tasks.forEach((task, index) => {
                    const taskId = `${day}-${block.timeRange}-${index}`;
                    if (edits[taskId]) {
                        block.tasks[index] = edits[taskId];
                    }
                });
            });
        }
        return dataWithEdits;
    }

    // --- UI Rendering ---
    function createDayHTML(day, timeBlocks) {
        const timeBlocksHTML = timeBlocks.map(block => {
            const taskCardsHTML = block.tasks.map((task, index) => {
                const taskId = `${day}-${block.timeRange}-${index}`;
                return `
                <div class="task-card" data-task-id="${taskId}">
                    <label class="task-checkbox">
                        <input type="checkbox">
                        <span contenteditable="true">${task}</span>
                    </label>
                    <div class="task-timer">
                        <span class="session-count" title="Work sessions completed">0/4</span>
                        <div class="timer-controls">
                            <button class="timer-btn" data-action="start" title="Start/Resume"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16zM9.555 7.168A.75.75 0 0 0 8 7.75v4.5a.75.75 0 0 0 1.555.582l3-2.25a.75.75 0 0 0 0-1.164l-3-2.25z" clip-rule="evenodd" /></svg></button>
                            <button class="timer-btn" data-action="pause" title="Pause" disabled><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M5.75 4.5a.75.75 0 0 0-.75.75v10.5a.75.75 0 0 0 1.5 0V5.25a.75.75 0 0 0-.75-.75zM14.25 4.5a.75.75 0 0 0-.75.75v10.5a.75.75 0 0 0 1.5 0V5.25a.75.75 0 0 0-.75-.75z" /></svg></button>
                            <button class="timer-btn" data-action="reset" title="Reset"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M15.312 11.342a5.5 5.5 0 1 1-6.624-8.868l.22-.22a.75.75 0 0 1 1.06 1.06l-.22.22a4 4 0 1 0 4.864 6.458.75.75 0 0 1 1.06 1.06l-.22.22z" clip-rule="evenodd" /></svg></button>
                        </div>
                        <div class="timer-display" data-mode="work" title="Click to switch mode">25:00</div>
                    </div>
                </div>`;
            }).join('');
            
            const focusClass = block.focus.includes('Q1') ? 'focus-q1' : 'focus-q2';
            return `
                <details class="time-block" data-time-range="${block.timeRange}">
                    <summary class="block-header">
                        <div class="block-header-title">
                            <h3>${block.timeRange} <span class="pomodoro-count">(${block.tasks.length})</span></h3>
                            <p class="block-focus ${focusClass}">${block.focus}</p>
                        </div>
                        <svg class="chevron" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </summary>
                    <div class="block-content">
                        <div class="progress-bar"><div class="progress-bar-track"><div class="progress"></div></div></div>
                        <div class="task-list">${taskCardsHTML}</div>
                    </div>
                </details>`;
        }).join('');
        return `<div id="${day}" class="day-schedule"><h1 class="day-title">${day.charAt(0).toUpperCase() + day.slice(1)}</h1>${timeBlocksHTML}</div>`;
    }

    function renderAllDays(data) {
        scheduleContainer.innerHTML = ''; 
        const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
        days.forEach(day => {
            if (data[day]) {
                scheduleContainer.insertAdjacentHTML('beforeend', createDayHTML(day, data[day]));
            }
        });
    }

    // --- Event Listeners ---
    function setupEventListeners() {
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                switchDay(e.target.dataset.day);
                window.location.hash = e.target.dataset.day;
            });
        });
        
        scheduleContainer.addEventListener('click', (e) => {
            const button = e.target.closest('.timer-btn');
            const display = e.target.closest('.timer-display');
            if (button) {
                const action = button.dataset.action;
                const taskCard = button.closest('.task-card');
                if (action === 'start') startTimer(taskCard);
                if (action === 'pause') pauseTimer(taskCard);
                if (action === 'reset') resetTimer(taskCard);
            }
            if (display) {
                switchMode(display.closest('.task-card'));
            }
        });

        scheduleContainer.addEventListener('change', (e) => {
            if (e.target.matches('.task-checkbox input')) {
                e.target.closest('.task-card').classList.toggle('completed', e.target.checked);
                updateProgressBars();
                saveCheckboxState();
            }
        });

        scheduleContainer.addEventListener('blur', (e) => {
            if (e.target.matches('.task-checkbox span[contenteditable="true"]')) {
                const taskCard = e.target.closest('.task-card');
                const taskId = taskCard.dataset.taskId;
                const newText = e.target.textContent;
                saveTextEdit(taskId, newText);
            }
        }, true);
        
        scheduleContainer.addEventListener('toggle', (e) => {
            if (e.target.matches('.time-block')) {
                saveCollapsibleState();
            }
        }, true);
    }
    
    // --- Timer Logic ---
    function startTimer(taskCard) {
        if (timerState.isRunning && timerState.activeCardId !== taskCard.dataset.taskId) {
            const previousCard = document.querySelector(`[data-task-id="${timerState.activeCardId}"]`);
            if (previousCard) resetTimer(previousCard);
        }
        timerState.isRunning = true;
        timerState.activeCardId = taskCard.dataset.taskId;
        taskCard.classList.add('active-timer');
        updateTimerButtons(taskCard, true);
        timerState.intervalId = setInterval(tick, 1000);
    }

    function pauseTimer(taskCard) {
        timerState.isRunning = false;
        clearInterval(timerState.intervalId);
        if (taskCard) updateTimerButtons(taskCard, false);
    }
    
    function resetTimer(taskCard) {
        const wasRunning = timerState.isRunning && timerState.activeCardId === taskCard.dataset.taskId;
        if (wasRunning) pauseTimer(taskCard);

        const display = taskCard.querySelector('.timer-display');
        const sessionCount = taskCard.querySelector('.session-count');
        display.dataset.mode = 'work';
        display.textContent = '25:00';
        display.classList.remove('rest-mode');
        sessionCount.textContent = '0/4';
        taskCard.classList.remove('active-timer');
        updateTimerButtons(taskCard, false);
        
        if (timerState.activeCardId === taskCard.dataset.taskId) timerState.activeCardId = null;
        saveTimerState(taskCard.dataset.taskId, { time: 25 * 60, mode: 'work', sessions: 0 });
    }
    
    function switchMode(taskCard) {
        if (timerState.isRunning && timerState.activeCardId === taskCard.dataset.taskId) return;
        const display = taskCard.querySelector('.timer-display');
        const newMode = display.dataset.mode === 'work' ? 'rest' : 'work';
        const newTime = newMode === 'work' ? 25 * 60 : 5 * 60;
        display.dataset.mode = newMode;
        display.textContent = formatTime(newTime);
        display.classList.toggle('rest-mode', newMode === 'rest');
        saveTimerState(taskCard.dataset.taskId, { time: newTime, mode: newMode });
    }

    function tick() {
        if (!timerState.activeCardId) { pauseTimer(null); return; }
        const activeCard = document.querySelector(`[data-task-id="${timerState.activeCardId}"]`);
        if (!activeCard) { pauseTimer(null); return; }
        
        const display = activeCard.querySelector('.timer-display');
        let time = timeToSeconds(display.textContent) - 1;
        display.textContent = formatTime(time);
        
        if (time < 0) handleSessionEnd(activeCard);
    }

    function handleSessionEnd(taskCard) {
        const display = taskCard.querySelector('.timer-display');
        const sessionCountEl = taskCard.querySelector('.session-count');
        
        if (display.dataset.mode === 'work') {
            let count = parseInt(sessionCountEl.textContent.split('/')[0]) + 1;
            sessionCountEl.textContent = `${count}/4`;
            saveTimerState(taskCard.dataset.taskId, { sessions: count });
        }
        switchMode(taskCard); // Switch to rest or back to work
        pauseTimer(taskCard); // Stop timer, require manual start for next session
        
        // Optional: play a sound
        // new Audio('path/to/sound.mp3').play();
    }

    // --- UI Update & Utility Functions ---
    function updateTimerButtons(taskCard, isRunning) {
        taskCard.querySelector('[data-action="start"]').disabled = isRunning;
        taskCard.querySelector('[data-action="pause"]').disabled = !isRunning;
    }
    function switchDay(day) { navLinks.forEach(link => link.classList.toggle('active', link.dataset.day === day)); document.querySelectorAll('.day-schedule').forEach(div => div.classList.remove('active')); const el = document.getElementById(day); if (el) { el.classList.add('active'); updateProgressBars(); } }
    function updateTimeAndHighlight() { const now = new Date(); const watTime = new Date(now.toLocaleString('en-US', { timeZone: 'Africa/Douala' })); const hours = watTime.getHours(); const minutes = watTime.getMinutes(); currentTimeEl.textContent = `${((hours + 11) % 12 + 1)}:${minutes.toString().padStart(2, '0')} ${hours >= 12 ? 'PM' : 'AM'}`; const todayName = watTime.toLocaleString('en-US', { weekday: 'long' }).toLowerCase(); const activeDayDiv = document.querySelector('.day-schedule.active'); if (!activeDayDiv || activeDayDiv.id !== todayName) { document.querySelectorAll('.time-block.current').forEach(b => b.classList.remove('current')); return; } const currentMilitaryTime = hours * 100 + minutes; activeDayDiv.querySelectorAll('.time-block').forEach(block => { const [startStr, endStr] = block.dataset.timeRange.split(' - '); const start = convertToMilitaryTime(startStr); const end = convertToMilitaryTime(endStr); if (start > end) { block.classList.toggle('current', currentMilitaryTime >= start || currentMilitaryTime < end); } else { block.classList.toggle('current', currentMilitaryTime >= start && currentMilitaryTime < end); } }); const currentBlock = activeDayDiv.querySelector('.time-block.current'); if (currentBlock) { const details = currentBlock.closest('details'); if(details && !details.open) { details.open = true; } } }
    function convertToMilitaryTime(timeStr) { const [time, modifier] = timeStr.split(' '); let [hours, minutes] = time.split(':').map(Number); if (hours === 12) { hours = (modifier === 'AM' ? 0 : 12); } if (modifier === 'PM' && hours < 12) { hours += 12; } return hours * 100 + minutes; }
    function updateProgressBars() { const activeDay = document.querySelector('.day-schedule.active'); if (!activeDay) return; activeDay.querySelectorAll('.time-block').forEach(block => { const tasks = block.querySelectorAll('.task-checkbox input'); const completedTasks = block.querySelectorAll('.task-checkbox input:checked'); const progressEl = block.querySelector('.progress'); if (progressEl) { const progressPercent = tasks.length > 0 ? (completedTasks.length / tasks.length) * 100 : 0; progressEl.style.width = `${progressPercent}%`; } }); }
    function formatTime(seconds) { const mins = Math.floor(seconds / 60); const secs = seconds % 60; return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`; }
    function timeToSeconds(timeStr) { const [mins, secs] = timeStr.split(':').map(Number); return (mins * 60) + secs; }

    // --- localStorage Persistence ---
    function saveState() { saveCheckboxState(); /* Timer state is saved on its own events */ }
    function loadState() { loadCheckboxState(); loadTimerState(); loadCollapsibleState(); updateProgressBars(); }
    function saveCheckboxState() { const state = {}; document.querySelectorAll('.task-card').forEach(card => { state[card.dataset.taskId] = card.querySelector('input').checked; }); localStorage.setItem('kustomakCheckboxState', JSON.stringify(state)); }
    function loadCheckboxState() { const state = JSON.parse(localStorage.getItem('kustomakCheckboxState')); if (!state) return; document.querySelectorAll('.task-card').forEach(card => { if (state[card.dataset.taskId]) { const checkbox = card.querySelector('input'); checkbox.checked = true; card.classList.add('completed'); } }); }
    function saveTextEdit(taskId, newText) { const edits = JSON.parse(localStorage.getItem('kustomakScheduleEdits')) || {}; edits[taskId] = newText; localStorage.setItem('kustomakScheduleEdits', JSON.stringify(edits)); }
    function saveTimerState(taskId, data) { const state = JSON.parse(localStorage.getItem('kustomakTimerState')) || {}; if (!state[taskId]) state[taskId] = {}; Object.assign(state[taskId], data); localStorage.setItem('kustomakTimerState', JSON.stringify(state)); }
    function loadTimerState() { const state = JSON.parse(localStorage.getItem('kustomakTimerState')); if (!state) return; document.querySelectorAll('.task-card').forEach(card => { const taskId = card.dataset.taskId; if (state[taskId]) { const display = card.querySelector('.timer-display'); const sessionCount = card.querySelector('.session-count'); display.textContent = formatTime(state[taskId].time || 25 * 60); display.dataset.mode = state[taskId].mode || 'work'; display.classList.toggle('rest-mode', display.dataset.mode === 'rest'); if (state[taskId].sessions !== undefined) sessionCount.textContent = `${state[taskId].sessions}/4`; } }); }
    function saveCollapsibleState() { const state = {}; document.querySelectorAll('.time-block[data-time-range]').forEach(details => { state[details.dataset.timeRange] = details.open; }); localStorage.setItem(`kustomakCollapsibleState-${document.body.dataset.day}`, JSON.stringify(state)); }
    function loadCollapsibleState() { const state = JSON.parse(localStorage.getItem(`kustomakCollapsibleState-${document.body.dataset.day}`)); if (!state) return; document.querySelectorAll('.time-block[data-time-range]').forEach(details => { if (state[details.dataset.timeRange] !== undefined) details.open = state[details.dataset.timeRange]; }); }
    
    // --- Start the Application ---
    init();
});